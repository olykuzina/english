import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import HomePage from './pages/HomePage'
import About from './pages/About'
import Guide from './pages/Guide'
import EnglishDrill from './components/EnglishDrill'
import './App.css'

function App() {
  return (
    <Router basename="/english-learning-app/">
      <div className="app">
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/app" element={<EnglishDrill />} />
            <Route path="/about" element={<About />} />
            <Route path="/guide" element={<Guide />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App
