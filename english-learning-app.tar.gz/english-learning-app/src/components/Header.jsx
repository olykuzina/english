import { Link } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import { useState } from 'react'
import './Header.css'

function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="header">
      <div className="container">
        <div className="header-content">
          <Link to="/" className="logo">
            <span className="logo-emoji">🎓</span>
            <span className="logo-text">English Quick Drill</span>
          </Link>

          <nav className={`nav ${isOpen ? 'open' : ''}`}>
            <Link to="/" onClick={() => setIsOpen(false)}>Home</Link>
            <Link to="/app" onClick={() => setIsOpen(false)}>Start Learning</Link>
            <Link to="/about" onClick={() => setIsOpen(false)}>Methodology</Link>
            <Link to="/guide" onClick={() => setIsOpen(false)}>Guide</Link>
          </nav>

          <button 
            className="menu-toggle"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header
