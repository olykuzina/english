import { Heart, Github, Mail, Linkedin } from 'lucide-react'
import './Footer.css'

function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3>English Quick Drill</h3>
            <p>Learn English using Oxford & Cambridge methodology</p>
            <div className="social-links">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
                <Github size={20} />
              </a>
              <a href="mailto:contact@example.com" aria-label="Email">
                <Mail size={20} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          <div className="footer-section">
            <h4>Quick Links</h4>
            <ul>
              <li><a href="/">Home</a></li>
              <li><a href="/about">About</a></li>
              <li><a href="/guide">Guide</a></li>
              <li><a href="/app">Start Learning</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Resources</h4>
            <ul>
              <li><a href="/docs/methodology">Methodology</a></li>
              <li><a href="/docs/contributing">Contributing</a></li>
              <li><a href="/docs/license">License</a></li>
              <li><a href="/docs/privacy">Privacy Policy</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Contact</h4>
            <p>Email: <a href="mailto:contact@example.com">contact@example.com</a></p>
            <p>GitHub: <a href="https://github.com" target="_blank" rel="noopener noreferrer">yourusername</a></p>
          </div>
        </div>

        <div className="footer-bottom">
          <p>
            Made with <Heart size={16} style={{ display: 'inline', color: '#ef4444' }} /> by Your Name
          </p>
          <p>&copy; {currentYear} English Quick Drill. All rights reserved.</p>
          <p>Licensed under <a href="https://opensource.org/licenses/MIT">MIT License</a></p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
