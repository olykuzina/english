import './About.css'

function About() {
  return (
    <div className="about-page">
      <section className="page-header">
        <div className="container">
          <h1>Oxford & Cambridge Methodology</h1>
          <p>Understanding the science behind effective English learning</p>
        </div>
      </section>

      <section className="about-content">
        <div className="container">
          <div className="content-section">
            <h2>Our Teaching Philosophy</h2>
            <p>
              English Quick Drill is built on decades of research from Oxford and Cambridge Universities. 
              We combine traditional methodology with modern spaced repetition to help you learn English 
              more effectively and retain knowledge longer.
            </p>
          </div>

          <div className="methodology-grid">
            <div className="methodology-card">
              <h3>🎯 Communicative Approach</h3>
              <p>
                We focus on real communication skills you need in daily life, not just grammar rules. 
                Learn phrases and patterns that native speakers actually use.
              </p>
            </div>

            <div className="methodology-card">
              <h3>📚 Corpus-Based Learning</h3>
              <p>
                Our vocabulary and phrases are selected from modern English corpora. You learn the most 
                frequently used and useful expressions for real situations.
              </p>
            </div>

            <div className="methodology-card">
              <h3>🔄 Spaced Repetition</h3>
              <p>
                The science is clear: spaced repetition dramatically improves retention. We implement 
                optimal intervals to cement learning in long-term memory.
              </p>
            </div>

            <div className="methodology-card">
              <h3>🎓 Chunking Technique</h3>
              <p>
                Instead of learning isolated words, we teach phrases (chunks). This mirrors how native 
                speakers actually learn and use language.
              </p>
            </div>

            <div className="methodology-card">
              <h3>💡 Active Recall</h3>
              <p>
                Testing yourself is more effective than passive reading. Our exercises force your brain 
                to retrieve information, strengthening neural pathways.
              </p>
            </div>

            <div className="methodology-card">
              <h3>🌍 Authentic Context</h3>
              <p>
                Learn English in context. Each session simulates real conversations and scenarios 
                you'll encounter in English-speaking environments.
              </p>
            </div>
          </div>

          <div className="content-section">
            <h2>The Four Learning Phases</h2>
            <p>
              Each session in English Quick Drill follows a scientifically-proven four-phase learning model:
            </p>

            <div className="phases">
              <div className="phase">
                <div className="phase-header">
                  <div className="phase-number">1</div>
                  <h3>Warmup Phase</h3>
                </div>
                <p>
                  Activate your existing knowledge. This primes your brain and creates a bridge between 
                  what you already know and what you're about to learn. Just 2-3 quick questions.
                </p>
              </div>

              <div className="phase">
                <div className="phase-header">
                  <div className="phase-number">2</div>
                  <h3>Learn Phase</h3>
                </div>
                <p>
                  Master new vocabulary, phrases, and sentence patterns. We present information in digestible 
                  chunks with clear explanations and examples. Active learning at its best.
                </p>
              </div>

              <div className="phase">
                <div className="phase-header">
                  <div className="phase-number">3</div>
                  <h3>Practice Phase</h3>
                </div>
                <p>
                  Multiple exercise types ensure you truly understand and can use what you've learned. 
                  From basic multiple choice to advanced sentence building.
                </p>
              </div>

              <div className="phase">
                <div className="phase-header">
                  <div className="phase-number">4</div>
                  <h3>Summary Phase</h3>
                </div>
                <p>
                  Review, consolidate, and celebrate your progress. Understand what you learned and 
                  prepare for the next session. Motivation is key to consistency.
                </p>
              </div>
            </div>
          </div>

          <div className="content-section">
            <h2>Research & Evidence</h2>
            <p>
              Our approach is grounded in:
            </p>
            <ul className="research-list">
              <li><strong>Spaced Repetition:</strong> Ebbinghaus's forgetting curve shows we need strategic review</li>
              <li><strong>Chunking:</strong> Miller's research shows we can remember ~7 items when grouped</li>
              <li><strong>Active Recall:</strong> Brown et al. prove testing beats passive studying</li>
              <li><strong>Communicative Competence:</strong> Hymes and Canale-Swain frameworks for real usage</li>
              <li><strong>Authenticity:</strong> Modern corpora show what English is really used for</li>
            </ul>
          </div>

          <div className="content-section">
            <h2>Why English Quick Drill?</h2>
            <ul className="features-list">
              <li>✓ Based on real Oxford & Cambridge methodology</li>
              <li>✓ Phrase-based learning (not isolated words)</li>
              <li>✓ Quick sessions (5-10 minutes) fit busy schedules</li>
              <li>✓ Progress tracking to motivate you</li>
              <li>✓ Free and open-source</li>
              <li>✓ Works offline (PWA)</li>
              <li>✓ Adaptive difficulty</li>
              <li>✓ Community-driven</li>
            </ul>
          </div>

          <div className="content-section">
            <h2>Get Started</h2>
            <p>
              Ready to learn English the right way? Start with a quick session and experience the difference 
              that proven methodology makes.
            </p>
            <a href="/app" className="cta-button">Start Learning Now</a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default About
