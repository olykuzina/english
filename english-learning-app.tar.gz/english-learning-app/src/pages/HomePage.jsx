import { Link } from 'react-router-dom'
import { ArrowRight, Zap, BookOpen, Brain, Target, Award, Users } from 'lucide-react'
import './HomePage.css'

function HomePage() {
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1>Master English Like Never Before</h1>
            <p>Learn using Oxford & Cambridge methodology. Quick drills, real conversations, lasting results.</p>
            <Link to="/app" className="cta-button">
              Start Learning Now <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features">
        <div className="container">
          <h2>Why Choose English Quick Drill?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <BookOpen size={32} />
              </div>
              <h3>Oxford & Cambridge Methods</h3>
              <p>Learn using proven methodologies from the world's top English institutions</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Zap size={32} />
              </div>
              <h3>5-10 Minute Sessions</h3>
              <p>Perfect for busy learners. No time-consuming lessons, just focused practice</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Brain size={32} />
              </div>
              <h3>Phrase-Based Learning</h3>
              <p>Master collocations and phrasal verbs like native speakers</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Target size={32} />
              </div>
              <h3>Progressive Difficulty</h3>
              <p>Start easy, gradually increase difficulty as you improve</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Award size={32} />
              </div>
              <h3>Progress Tracking</h3>
              <p>Monitor your improvement with detailed statistics and achievements</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Users size={32} />
              </div>
              <h3>Community Support</h3>
              <p>Join thousands of learners on their English journey</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="how-it-works">
        <div className="container">
          <h2>How It Works</h2>
          <div className="steps">
            <div className="step">
              <div className="step-number">1</div>
              <h3>Warmup Phase</h3>
              <p>Activate your existing knowledge with quick questions</p>
            </div>
            <div className="step">
              <div className="step-number">2</div>
              <h3>Learn Phase</h3>
              <p>Master new vocabulary, phrases and sentence patterns</p>
            </div>
            <div className="step">
              <div className="step-number">3</div>
              <h3>Practice Phase</h3>
              <p>Complete multiple exercise types for better retention</p>
            </div>
            <div className="step">
              <div className="step-number">4</div>
              <h3>Summary Phase</h3>
              <p>Review progress and plan your next learning steps</p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="benefits">
        <div className="container">
          <h2>Benefits You'll Get</h2>
          <ul className="benefits-list">
            <li>✓ Improve English speaking confidence</li>
            <li>✓ Master real, practical vocabulary</li>
            <li>✓ Build stronger sentence patterns</li>
            <li>✓ Learn at your own pace</li>
            <li>✓ Free and open-source</li>
            <li>✓ No hidden ads or paywalls</li>
          </ul>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <h2>Ready to Transform Your English?</h2>
          <p>Join thousands of learners who are already improving their English</p>
          <Link to="/app" className="cta-button cta-button-large">
            Start Your Learning Journey Today
          </Link>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="faq">
        <div className="container">
          <h2>Frequently Asked Questions</h2>
          <div className="faq-grid">
            <div className="faq-item">
              <h4>Is it really free?</h4>
              <p>Yes! English Quick Drill is completely free and open-source. No hidden fees or premium features locked behind a paywall.</p>
            </div>
            <div className="faq-item">
              <h4>How long are the sessions?</h4>
              <p>Each session takes 5-10 minutes. Perfect for learning during breaks, commutes, or before bed.</p>
            </div>
            <div className="faq-item">
              <h4>What's the methodology?</h4>
              <p>We use Oxford & Cambridge English learning methodologies combined with modern spaced repetition techniques.</p>
            </div>
            <div className="faq-item">
              <h4>Can I use it offline?</h4>
              <p>Yes! The app has offline support through PWA technology. Download once and learn anywhere.</p>
            </div>
            <div className="faq-item">
              <h4>For which level is it?</h4>
              <p>The app adapts to your level - from A1 beginner to C1 advanced. Start where you are.</p>
            </div>
            <div className="faq-item">
              <h4>Can I track my progress?</h4>
              <p>Yes! Your progress is saved locally. View detailed statistics about your learning journey.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage
