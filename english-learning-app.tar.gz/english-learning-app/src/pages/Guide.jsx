import './Guide.css'

function Guide() {
  return (
    <div className="guide-page">
      <section className="page-header">
        <div className="container">
          <h1>How to Use English Quick Drill</h1>
          <p>Master English in just 5-10 minutes per day</p>
        </div>
      </section>

      <section className="guide-content">
        <div className="container">
          <div className="content-section">
            <h2>Getting Started</h2>
            <ol className="guide-steps">
              <li>
                <h3>Choose a Theme</h3>
                <p>Start by selecting a theme that interests you (Daily Life, Travel, Work, etc.). Pick topics that are relevant to your life.</p>
              </li>
              <li>
                <h3>Answer Warmup Question</h3>
                <p>Start with a quick question to activate your existing knowledge. This helps your brain prepare for new learning.</p>
              </li>
              <li>
                <h3>Learn New Content</h3>
                <p>Review new vocabulary, phrases, and sentence patterns. Pay attention to collocations (word combinations) - this is how native speakers speak.</p>
              </li>
              <li>
                <h3>Complete Exercises</h3>
                <p>Practice what you learned through various exercise types. Each one reinforces your knowledge in different ways.</p>
              </li>
              <li>
                <h3>Review Summary</h3>
                <p>See your results and understand what you learned. This helps consolidate knowledge in your memory.</p>
              </li>
            </ol>
          </div>

          <div className="content-section">
            <h2>Exercise Types</h2>
            <div className="exercise-types">
              <div className="exercise-card">
                <h3>Multiple Choice</h3>
                <p>Select the correct answer from 4 options. Good for testing understanding and building confidence.</p>
                <div className="example">
                  <p><strong>Example:</strong></p>
                  <p>Which phrase means "to relax"?</p>
                  <p>a) Take it easy &nbsp; b) Take it hard &nbsp; c) Take it slow &nbsp; d) Take it fast</p>
                </div>
              </div>

              <div className="exercise-card">
                <h3>Matching</h3>
                <p>Match phrases to their meanings or situations. Builds vocabulary recognition.</p>
                <div className="example">
                  <p><strong>Example:</strong></p>
                  <p>Match the phrase to the situation:</p>
                  <p>"I'm afraid not" → A polite way to refuse</p>
                </div>
              </div>

              <div className="exercise-card">
                <h3>Fill in the Blank</h3>
                <p>Complete sentences with missing words or phrases. Tests active recall and usage.</p>
                <div className="example">
                  <p><strong>Example:</strong></p>
                  <p>I usually _____ (wake up) at 7 AM</p>
                </div>
              </div>

              <div className="exercise-card">
                <h3>Sentence Builder</h3>
                <p>Arrange words to form correct sentences. Reinforces sentence structure and grammar.</p>
                <div className="example">
                  <p><strong>Example:</strong></p>
                  <p>Arrange: I / always / coffee / morning / have / in / my</p>
                </div>
              </div>

              <div className="exercise-card">
                <h3>Collocation Fill</h3>
                <p>Complete common word combinations (collocations). Master phrases like native speakers.</p>
                <div className="example">
                  <p><strong>Example:</strong></p>
                  <p>_____ an appointment (Make / Do / Take)</p>
                </div>
              </div>

              <div className="exercise-card">
                <h3>Dialogue Completion</h3>
                <p>Fill in missing parts of conversations. Learn natural speaking patterns.</p>
                <div className="example">
                  <p><strong>Example:</strong></p>
                  <p>A: "How are you?"</p>
                  <p>B: "I'm _____ thanks"</p>
                </div>
              </div>
            </div>
          </div>

          <div className="content-section">
            <h2>Tips for Success</h2>
            <div className="tips-grid">
              <div className="tip">
                <h3>📅 Be Consistent</h3>
                <p>Do one session every day, even if it's just 5 minutes. Consistency beats long sessions.</p>
              </div>
              <div className="tip">
                <h3>🧠 Focus on Phrases</h3>
                <p>Don't just learn words - learn how they're used together. This is what native speakers do.</p>
              </div>
              <div className="tip">
                <h3>✍️ Write Examples</h3>
                <p>Write your own sentences using new phrases. Use them in messages or journal entries.</p>
              </div>
              <div className="tip">
                <h3>🎤 Speak Out Loud</h3>
                <p>Say the phrases and sentences aloud. This helps with pronunciation and memory.</p>
              </div>
              <div className="tip">
                <h3>🔄 Revisit Difficult Topics</h3>
                <p>Don't skip themes you find hard. Repeat them until they become automatic.</p>
              </div>
              <div className="tip">
                <h3>📊 Track Progress</h3>
                <p>Watch your stats grow. Seeing improvement is motivating and shows you're making progress.</p>
              </div>
            </div>
          </div>

          <div className="content-section">
            <h2>Understanding Your Stats</h2>
            <div className="stats-explanation">
              <div className="stat-item">
                <h3>Correct Answers</h3>
                <p>The percentage of exercises you got right. Aim for 80%+ but don't stress about 100% - some errors help learning!</p>
              </div>
              <div className="stat-item">
                <h3>Streak</h3>
                <p>How many consecutive days you've done sessions. Build momentum and make it a habit!</p>
              </div>
              <div className="stat-item">
                <h3>Words Learned</h3>
                <p>Total vocabulary and phrases you've encountered. This grows with each session.</p>
              </div>
              <div className="stat-item">
                <h3>Themes Completed</h3>
                <p>Different topics you've practiced. Try to complete all themes for well-rounded learning.</p>
              </div>
            </div>
          </div>

          <div className="content-section">
            <h2>Common Questions</h2>
            <div className="faq-items">
              <div className="faq-item">
                <h3>How long does each session take?</h3>
                <p>5-10 minutes. This is intentional - short sessions keep you motivated and fit into busy schedules.</p>
              </div>
              <div className="faq-item">
                <h3>Can I do multiple sessions per day?</h3>
                <p>Yes! But remember: consistency matters more than quantity. Daily 5-minute sessions beat sporadic 30-minute marathons.</p>
              </div>
              <div className="faq-item">
                <h3>What level is this for?</h3>
                <p>Currently A2-B1 (Elementary to Intermediate). As we grow, we'll add more levels from A1 to C1.</p>
              </div>
              <div className="faq-item">
                <h3>Does it work offline?</h3>
                <p>Yes! The app is a Progressive Web App (PWA). You can use it offline - your progress syncs when you're back online.</p>
              </div>
              <div className="faq-item">
                <h3>What if I get an answer wrong?</h3>
                <p>Great! Mistakes are how we learn. Pay attention to the explanation and try similar exercises again.</p>
              </div>
              <div className="faq-item">
                <h3>Can I reset my progress?</h3>
                <p>Yes, use the Reset button on the homepage. But remember, your learning is in your brain, not the stats!</p>
              </div>
            </div>
          </div>

          <div className="content-section">
            <h2>Ready to Start?</h2>
            <p>You now know everything you need! Pick a theme that interests you and do your first session.</p>
            <a href="/app" className="cta-button">Start Your First Session</a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Guide
