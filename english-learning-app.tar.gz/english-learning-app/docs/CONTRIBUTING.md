# 🤝 Contributing Guide

Thank you for your interest in contributing to English Quick Drill! We welcome all contributions, big and small.

## Code of Conduct

- Be respectful and inclusive
- Welcome learners at all levels
- Focus on improving the learning experience
- No discrimination or harassment

## Ways to Contribute

### 1. Report Bugs 🐛

Found a bug? Help us fix it!

1. Go to [Issues](https://github.com/yourusername/english-learning-app/issues)
2. Click "New Issue"
3. Use "Bug Report" template
4. Include:
   - What you were doing
   - What went wrong
   - Expected behavior
   - Browser/device info
   - Screenshots if helpful

### 2. Suggest Features 💡

Have an idea to improve the app?

1. Check [Issues](https://github.com/yourusername/english-learning-app/issues) - maybe already suggested
2. Click "New Issue"
3. Use "Feature Request" template
4. Describe:
   - The problem you want to solve
   - Your proposed solution
   - Benefits for users
   - Examples if applicable

### 3. Add Content 📚

Want to add new lessons or exercises?

- **New Themes**: Add themes like "Business English" or "Academic"
- **New Exercises**: Create new exercise types
- **Vocabulary**: Contribute new words and phrases
- **Dialogues**: Write realistic conversations

See [Exercise Types](#exercise-types) section.

### 4. Improve Code 💻

### 5. Improve Documentation 📖

Found unclear explanations? Help clarify!

- Update [README.md](../README.md)
- Improve guides in [docs/](../)
- Add comments to complex code
- Fix typos

### 6. Test & Report

- Test on different devices
- Test on mobile vs desktop
- Test in different browsers
- Report findings in Issues

## Getting Started with Development

### Prerequisites

- Node.js 18+
- Git
- Code editor (VS Code recommended)

### Setup

```bash
# 1. Fork repository on GitHub
# Click "Fork" button on repo page

# 2. Clone your fork
git clone https://github.com/YOUR_USERNAME/english-learning-app.git
cd english-learning-app

# 3. Add upstream remote
git remote add upstream https://github.com/yourusername/english-learning-app.git

# 4. Install dependencies
npm install

# 5. Start development server
npm run dev
# Open http://localhost:3000
```

### Create Feature Branch

```bash
# Update from upstream
git fetch upstream
git rebase upstream/main

# Create feature branch
git checkout -b feature/my-feature-name

# Make your changes...

# Commit with clear message
git commit -m "Add feature: describe what you added"

# Push to your fork
git push origin feature/my-feature-name
```

### Submit Pull Request

1. Go to your fork on GitHub
2. Click "Compare & pull request"
3. Fill out PR template:
   - **Title**: Clear, concise description
   - **Description**: What changes and why
   - **Related Issues**: Link to relevant issues
   - **Testing**: How you tested the changes
   - **Screenshots**: If UI changes

4. Ensure:
   - ✅ Code follows project style
   - ✅ No console errors
   - ✅ Mobile responsive
   - ✅ All tests pass

## Code Style

### JavaScript/React

```jsx
// Use functional components
function MyComponent() {
  const [state, setState] = useState(null)
  
  return (
    <div>
      {/* JSX */}
    </div>
  )
}

export default MyComponent
```

### CSS

```css
/* Use semantic class names */
.feature-card {
  /* ... */
}

.feature-card__title {
  /* ... */
}

.feature-card--highlighted {
  /* ... */
}
```

### Naming Conventions

- **Components**: PascalCase (HomePage.jsx)
- **Files**: PascalCase for components, lowercase for utilities
- **Variables**: camelCase
- **Constants**: UPPER_SNAKE_CASE

### Formatting

- Use 2-space indentation
- No trailing whitespace
- Max line length: 100 characters
- Use semicolons

## Exercise Types

Want to add new exercise types? Here's the structure:

### 1. Multiple Choice

```javascript
{
  type: "multiple_choice",
  instruction: "Select the correct answer",
  question: "What does 'take it easy' mean?",
  options: [
    "Relax and don't worry",
    "Work very hard",
    "Leave immediately",
    "Speak slowly"
  ],
  correctAnswer: 0,
  explanation: "This phrase means to relax and not stress"
}
```

### 2. Fill in the Blank

```javascript
{
  type: "fill_blank",
  instruction: "Complete the sentence",
  sentence: "I usually ____ coffee in the morning",
  options: ["drink", "make", "take", "have"],
  correctAnswer: "drink",
  explanation: "We use 'drink' with beverages"
}
```

### 3. Sentence Builder

```javascript
{
  type: "sentence_builder",
  instruction: "Arrange words to form a sentence",
  words: ["morning", "I", "every", "run"],
  correctAnswer: "I run every morning",
  explanation: "Subject + Verb + Time"
}
```

### 4. Matching

```javascript
{
  type: "matching",
  instruction: "Match phrases to meanings",
  pairs: [
    {
      phrase: "Take it easy",
      meanings: ["Relax", "Work hard", "Hurry up"],
      correct: 0
    }
  ]
}
```

### 5. Dialogue Completion

```javascript
{
  type: "dialogue",
  instruction: "Complete the conversation",
  dialogue: [
    { speaker: "A", text: "How are you?" },
    { speaker: "B", text: "_____" }
  ],
  options: ["I'm fine", "Yes", "No"],
  correct: "I'm fine"
}
```

### 6. Collocation Fill

```javascript
{
  type: "collocation",
  instruction: "Complete the phrase",
  phrase: "____ an appointment",
  options: ["Do", "Make", "Have"],
  correct: "Make",
  explanation: "Correct collocation: 'make an appointment'"
}
```

## Testing

Before submitting PR:

```bash
# Build the project (check for errors)
npm run build

# Start dev server and test manually
npm run dev

# Test on mobile by visiting:
# http://YOUR_IP:3000 from phone on same network
```

## Documentation

When adding features:

1. **Update README.md** if it's a major feature
2. **Add inline comments** for complex code
3. **Update relevant docs** in `/docs` folder
4. **Include examples** when helpful

## Commit Message Format

```
[Type]: Brief description (imperative mood)

Detailed explanation of changes.
Explain WHY, not just WHAT.

Fixes #123
Related to #456
```

### Types
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting only
- `refactor`: Code restructure
- `perf`: Performance improvement
- `test`: Add/update tests
- `chore`: Dependencies, build tools

### Examples
```
feat: Add collocation matching exercise type
fix: Resolve mobile menu closing on route change
docs: Update methodology explanation
style: Format component files with 2-space indent
```

## Review Process

1. **Automated Checks**
   - Code builds successfully
   - No console errors
   - Mobile responsive

2. **Manual Review**
   - Code quality
   - Follows project style
   - Clear commits
   - Good documentation

3. **Approval**
   - At least 1 maintainer review
   - Ready to merge!

## Questions?

- Open an Issue with "question" label
- Check [Discussions](https://github.com/yourusername/english-learning-app/discussions)
- Comment on related PRs
- Email: contact@example.com

## Recognition

Contributors will be recognized in:
- [CONTRIBUTORS.md](./CONTRIBUTORS.md)
- GitHub contributors page
- Release notes

## License

By contributing, you agree your code will be licensed under MIT License.

---

## Quick Checklist

Before submitting PR:

- [ ] Forked repository
- [ ] Created feature branch
- [ ] Made clear, focused changes
- [ ] Tested locally (works on mobile too)
- [ ] No console errors
- [ ] Followed code style
- [ ] Clear commit messages
- [ ] Updated documentation
- [ ] Added related issue links
- [ ] Opened PR with description

---

**Thank you for contributing!** 🎉

Your effort helps thousands of English learners around the world!
