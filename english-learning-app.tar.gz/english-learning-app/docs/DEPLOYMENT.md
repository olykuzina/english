# 🚀 Deployment Guide

How to deploy English Quick Drill to GitHub Pages.

## Prerequisites

- GitHub account
- Repository with project files
- Git installed locally

## Automatic Deployment with GitHub Actions

Our project uses GitHub Actions to automatically build and deploy on every push.

### How it Works

1. **Push to main** → Triggers GitHub Actions workflow
2. **Build** → npm install, npm run build
3. **Deploy** → Publishes to `gh-pages` branch
4. **Live** → Your site updates in 1-2 minutes

### Workflow File

The deployment workflow is in `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

# ... automatically builds and deploys
```

## Setup GitHub Pages

### Step 1: Ensure Correct Branch

Make sure your main branch is called `main`:

```bash
# Check current branch name
git branch

# If it's 'master', rename to 'main'
git branch -M main
git push -u origin main
```

### Step 2: Enable GitHub Pages

1. Go to your repository → **Settings**
2. Left sidebar → **Pages**
3. **Source**: "Deploy from a branch"
4. **Branch**: Select `gh-pages` and `/(root)`
5. **Save**

### Step 3: Wait for First Build

- GitHub Actions will automatically create `gh-pages` branch
- Check **Actions** tab to see workflow status
- Wait for ✅ (usually 1-2 minutes)

### Step 4: Visit Your Site

Your site will be available at:
```
https://yourusername.github.io/english-learning-app/
```

## Configuration

### vite.config.js

The `base` setting must match your repository name:

```javascript
export default defineConfig({
  base: '/english-learning-app/', // matches repo name
  // ...
})
```

If you rename repository, update this!

### Environment Variables

For GitHub Actions, use **GitHub Secrets**:

1. Go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret**
3. Add secrets:
   - `VITE_ANTHROPIC_API_KEY`: Your Claude API key
   - `VITE_GA_MEASUREMENT_ID`: Google Analytics ID (optional)

In workflow, reference them:

```yaml
env:
  VITE_ANTHROPIC_API_KEY: ${{ secrets.VITE_ANTHROPIC_API_KEY }}
```

## Manual Deployment (Alternative)

If you want to deploy manually without GitHub Actions:

```bash
# 1. Build the project
npm run build

# 2. Install gh-pages
npm install --save-dev gh-pages

# 3. Add to package.json:
# "deploy": "npm run build && gh-pages -d dist"

# 4. Deploy
npm run deploy
```

## Troubleshooting

### Deployment Fails

Check **Actions** tab:

1. Click on failed workflow
2. Expand steps to see error messages
3. Common issues:
   - Node version mismatch
   - Missing dependencies
   - Build errors in code

Solution:
```bash
# Test build locally first
npm ci  # Clean install
npm run build  # Should succeed
```

### Site Shows 404

1. Verify `gh-pages` branch exists in repo
2. Check GitHub Pages is enabled in Settings
3. Hard refresh browser (Ctrl+Shift+R)
4. Clear browser cache

### Wrong Repository Name in Config

If you renamed repository after setup:

1. Update `vite.config.js`:
```javascript
base: '/new-repo-name/',  // Update this
```

2. Commit and push:
```bash
git add vite.config.js
git commit -m "Update base path for renamed repository"
git push
```

### CNAME Not Working

For custom domains:

1. Create `public/CNAME` file:
```
yourdomain.com
```

2. Add DNS CNAME record pointing to:
```
yourusername.github.io
```

3. Wait 5-30 minutes for SSL certificate

## Performance Tips

### Reduce Bundle Size

```bash
# Check bundle size
npm run build

# Use dynamic imports for routes
const HomePage = lazy(() => import('./pages/HomePage'))
```

### Enable Compression

GitHub Pages automatically serves files with gzip compression. No action needed!

### Cache Busting

Vite automatically handles cache busting with hashed filenames:
```
app.a1b2c3d4.js  # Changes on rebuild
```

## Custom Domain Setup

### Using a Custom Domain

1. Register domain (Namecheap, GoDaddy, etc.)
2. Update DNS records to point to GitHub Pages
3. Add domain in GitHub Settings → Pages

### For Apex Domain (yourdomain.com)

Add A records pointing to GitHub's IP:
```
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153
```

### For Subdomain (app.yourdomain.com)

Add CNAME record:
```
yourusername.github.io
```

See [GitHub Custom Domain Guide](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site) for details.

## Security

### Protect Secrets

❌ **DO NOT:**
- Commit `.env` file with real API keys
- Expose keys in client-side code

✅ **DO:**
- Use GitHub Secrets for CI/CD
- Create serverless proxy for APIs
- Use `.env.example` as template

### HTTPS

GitHub Pages automatically provides HTTPS (free SSL certificate).

## Monitoring & Analytics

### GitHub Actions

Check deployment status:
1. Go to **Actions** tab
2. See recent workflow runs
3. Click for detailed logs

### Google Analytics (Optional)

1. Get Google Analytics ID
2. Add to `public/index.html`:
```html
<script>
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

Or use GitHub Secret approach mentioned above.

## Rollback

If something breaks, rollback to previous version:

```bash
# See recent commits
git log --oneline

# Revert to specific commit
git revert <commit-hash>
git push

# Or revert last commit
git revert HEAD
git push
```

GitHub Actions will automatically rebuild and redeploy.

## Updates & Maintenance

### Update Dependencies

```bash
# Check for outdated packages
npm outdated

# Update packages
npm update

# For major updates
npm upgrade react@latest
```

Then commit and push - automatic deployment happens!

### Monitoring Performance

Use tools to monitor site:
- [Lighthouse CI](https://github.com/GoogleChrome/lighthouse-ci)
- [WebPageTest](https://www.webpagetest.org/)
- [GTmetrix](https://gtmetrix.com/)

## Advanced: Self-Hosted Deployment

To deploy elsewhere (not GitHub Pages):

### Vercel (Recommended Alternative)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# It will handle everything automatically
```

### Netlify

1. Push to GitHub
2. Connect repo on [netlify.com](https://netlify.com)
3. Set build command: `npm run build`
4. Set publish folder: `dist`
5. Auto-deploys on push!

### Self-Hosted Server

```bash
# Build
npm run build

# Upload 'dist' folder to your server
# Configure server to serve index.html for all routes
# Example for nginx:
try_files $uri $uri/ /index.html;
```

## Summary

The deployment process is fully automated:

```
git push → GitHub Actions → Build & Test → Deploy → Live
```

Just push to `main` branch, and your site updates automatically! 🎉

---

**Questions?** See [GETTING_STARTED.md](./GETTING_STARTED.md) or open an issue.
