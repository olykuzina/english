# 🚀 Getting Started Guide

Complete step-by-step guide to set up and deploy English Quick Drill on GitHub Pages.

## Prerequisites

- GitHub account (free)
- Node.js 18+ (download from [nodejs.org](https://nodejs.org))
- Git installed on your computer
- Text editor (VS Code recommended)

## Step 1: Create GitHub Repository

1. Go to [github.com/new](https://github.com/new)
2. **Repository name**: `english-learning-app`
3. **Description**: "Interactive English learning app using Oxford & Cambridge methodology"
4. **Visibility**: Public
5. **Initialize**: Do NOT add README, .gitignore, or license
6. Click "Create repository"

## Step 2: Clone Locally & Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/english-learning-app.git
cd english-learning-app

# Install Node dependencies
npm install
```

## Step 3: Start Development Server

```bash
# Run development server
npm run dev

# Open http://localhost:3000 in your browser
```

You should see:
- 🎓 English Quick Drill header
- Hero section with "Start Learning Now" button
- Features and how-it-works sections
- Footer with links

## Step 4: Customize Your Project

### Update package.json
```json
{
  "author": "Your Name",
  "homepage": "https://yourusername.github.io/english-learning-app/",
  "repository": {
    "url": "https://github.com/yourusername/english-learning-app.git"
  }
}
```

### Update public/index.html
- Replace `yourusername` with your GitHub username
- Update meta descriptions if desired
- Update Google Analytics ID (optional)

### Update Footer (src/components/Footer.jsx)
- Change email address
- Update social media links
- Change author name

### Setup Environment (optional)
```bash
# Create .env file
cp .env.example .env

# Add your Anthropic API key (or leave blank to use mock data)
VITE_ANTHROPIC_API_KEY=sk_...
```

## Step 5: Build for Production

```bash
# Build optimized production version
npm run build

# This creates 'dist' folder with optimized files
# Test the build locally
npm run preview
```

## Step 6: First Commit & Push

```bash
# Stage all files
git add .

# Create initial commit
git commit -m "Initial commit: English Learning App"

# Set main branch
git branch -M main

# Add remote origin (if not already added)
git remote add origin https://github.com/yourusername/english-learning-app.git

# Push to GitHub
git push -u origin main
```

## Step 7: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** tab
3. Scroll to **Pages** section (left sidebar)
4. **Source**: Select "Deploy from a branch"
5. **Branch**: Select `gh-pages` and `/(root)`
6. Click **Save**

⏳ GitHub Actions will automatically:
- Install dependencies
- Build the project
- Deploy to `gh-pages` branch
- Your site will be live in 1-2 minutes

## Step 8: Verify Deployment

1. Go to your repository → **Actions** tab
2. You should see a workflow running: "Deploy to GitHub Pages"
3. Wait for ✅ (usually 1-2 minutes)
4. Visit: **`https://yourusername.github.io/english-learning-app/`**

🎉 **Your site is live!**

## Step 9: Custom Domain (Optional)

To use your own domain (e.g., englishlearn.com):

1. Go to **Settings → Pages**
2. Under "Custom domain", enter your domain
3. Add DNS records as shown (CNAME, A, or ALIAS)
4. Wait 5-30 minutes for SSL certificate
5. Done!

See [GitHub Pages Documentation](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site) for detailed instructions.

## Step 10: Make Changes & Auto-Deploy

Now you can make changes anytime:

```bash
# Make some changes to the code

# Commit and push
git add .
git commit -m "Describe your changes"
git push

# GitHub Actions automatically:
# 1. Builds the project
# 2. Deploys to gh-pages
# 3. Your site updates in 1-2 minutes
```

## Troubleshooting

### Build fails with "npm ci"
```bash
# Clear npm cache and try again
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

### Site shows 404 error
1. Check your repository settings → Pages
2. Make sure `gh-pages` branch exists
3. Check that it's set as source branch
4. Wait a few minutes and refresh

### Changes not showing after push
1. Check Actions tab - build might still be running
2. Hard refresh your browser (Ctrl+Shift+R or Cmd+Shift+R)
3. Check that files were pushed to main branch

### GitHub Pages not enabled
1. Ensure repository is **Public**
2. Check Settings → Pages
3. Source should be set to `gh-pages` branch

## Next Steps

1. **Customize**: Update colors, text, and content
2. **Add Features**: Modify components and pages
3. **Test Mobile**: Check responsiveness on phone
4. **SEO**: Update meta tags and descriptions
5. **Analytics**: Set up Google Analytics (optional)
6. **Share**: Tell friends and share your site!

## Additional Resources

- [React Documentation](https://react.dev)
- [Vite Documentation](https://vitejs.dev)
- [GitHub Pages Guide](https://pages.github.com)
- [GitHub Actions Guide](https://github.com/features/actions)

## Getting Help

- Check [GitHub Issues](https://github.com/yourusername/english-learning-app/issues)
- Read [User Guide](./USER_GUIDE.md)
- Review [Methodology](./METHODOLOGY.md)
- Open an Issue with "question" label

---

**Congratulations! You're all set!** 🎉

Your English Quick Drill app is now live on the internet. Start learning and sharing it with others!
